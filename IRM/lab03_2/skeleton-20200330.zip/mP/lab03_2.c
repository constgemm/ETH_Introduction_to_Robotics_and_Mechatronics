/**
 * Lab03_2 Digital Filtering
 *
 * \brief This code reads an input file, filters it and saves it in a file,
 *
*/



/* These are system level includes */
#include <stdio.h>
#include <stdint.h>
#include <math.h>
#include <unistd.h>
#include "digital_filter.h"

int main()
{
  
    
 ///////  Prelab Q4 /////////
    
   
    /* call the function filtering with different values for smoothing filter */
    
    //example:
    filtering(10);
    

    
  return 0;
}



